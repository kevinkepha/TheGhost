package psyco.kevin.dream;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class AddDreamActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText details;
    private EditText night;
    private Button addButton;
    private RadioGroup radioTagGroup;
    private RadioButton radioTagButton;
    DBHelper mydb;
    String thewordfromsearch,thenight;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_dream);
        details =findViewById(R.id.editText);
        night =findViewById(R.id.editText2);
        radioTagGroup = findViewById(R.id.radioSex);
        addButton = findViewById(R.id.SEARCHBTN);
        addButton.setOnClickListener(this);
    }


    private void Verifiydata() {
        // get selected radio button from radioGroup
        int selectedId = radioTagGroup.getCheckedRadioButtonId();

        // find the radiobutton by returned id
        radioTagButton =  findViewById(selectedId);
        thewordfromsearch = details.getText().toString();
        thenight = night.getText().toString();

        if (thewordfromsearch.matches("") || thenight .matches("")) {
            Toast.makeText(AddDreamActivity.this, "You did not enter your dream or night", Toast.LENGTH_SHORT).show();
            return;
        }else {

            addDream(radioTagButton,thewordfromsearch,thenight);
            Toast.makeText(AddDreamActivity.this, "Your dream has been saved successfully!", Toast.LENGTH_SHORT).show();
            finish();

        }

    }

    private void addDream(RadioButton radioTagButton, String thewordfromsearch, String thenight) {
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.SEARCHBTN:
                Verifiydata();
                break;

        }
    }

}
