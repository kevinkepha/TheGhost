package psyco.kevin.dream;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

public class ShowDream extends AppCompatActivity {
    public final static String EXTRA_MESSAGE = "MESSAGE";
    private ListView listView;
    DBHelper mydb;
    Bundle extras;
    int id_To_Update = 0;
    String Value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_dream);
        listView=findViewById(R.id.listView);
        mydb = new DBHelper(this);
        extras = getIntent().getExtras();
         Value = extras.getString("search");
    // getData();

    }

    private void getData() {
        if(Value !=""){
            //means this is the view part not the add contact part.
            Cursor rs = mydb.getData(Value);
            rs.moveToFirst();

            String detaile = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME));
            String tag = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_TAG));
            String night = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NIGHT));
            String categori = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_CAT));

            if (!rs.isClosed())  {
                rs.close();
            }
        }
    }


}

