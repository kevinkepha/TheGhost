package psyco.kevin.dream;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    FloatingActionButton fab;
    Toolbar toolbar;
    EditText edittextsearch;
    Button btnsearch,tag1,tag2,tag3,tag4,tag5,tag6;
    FrameLayout framsearch;

String thewordfromsearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar =  findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initialize();




    }

    private void initialize() {
        fab =  findViewById(R.id.fab);
        edittextsearch=findViewById(R.id.editText);
        btnsearch=findViewById(R.id.SEARCHBTN);
        framsearch=findViewById(R.id.searchfrem);
        tag1=findViewById(R.id.tag);
        tag2=findViewById(R.id.tag2);
        tag3=findViewById(R.id.tag3);
        tag4=findViewById(R.id.tag4);
        tag5=findViewById(R.id.tag5);
        tag6=findViewById(R.id.tag6);
        btnsearch.setOnClickListener(this);
        framsearch.setOnClickListener(this);
        tag1.setOnClickListener(this);
        tag2.setOnClickListener(this);
        tag3.setOnClickListener(this);
        tag4.setOnClickListener(this);
        tag5.setOnClickListener(this);
        tag6.setOnClickListener(this);
        fab.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Intent intet;
        thewordfromsearch = edittextsearch.getText().toString();

        // Perform action on click
        switch (v.getId()) {
            case R.id.SEARCHBTN:
               if (thewordfromsearch.matches("")) {
                    Toast.makeText(this, "You did not enter a keyword", Toast.LENGTH_SHORT).show();
                    return;
                }else {
                   intet = new Intent(MainActivity.this, ShowDream.class);
                   intet.putExtra("search", thewordfromsearch);
                   startActivity(intet);
               }
                break;
            case R.id.searchfrem:
                if (thewordfromsearch.matches("")) {
                    Toast.makeText(this, "You did not enter a keyword", Toast.LENGTH_SHORT).show();
                    return;
                }else {
                    intet = new Intent(MainActivity.this, ShowDream.class);
                    intet.putExtra("search", thewordfromsearch);
                    startActivity(intet);
                }
                break;
            case R.id.fab:
                Snackbar.make(btnsearch, "Hi Ghost! Add your dream!", Snackbar.LENGTH_LONG)
                        .setAction("Ok", null).show();
                intet = new Intent(MainActivity.this, AddDreamActivity.class);
                startActivity(intet);
                break;
            case R.id.tag:
                thewordfromsearch="flower";
                intet=new Intent(MainActivity.this,ShowDream.class);
                intet.putExtra("search",thewordfromsearch);
                startActivity(intet);
                break;
            case R.id.tag2:
                thewordfromsearch="flying";
                intet=new Intent(MainActivity.this,ShowDream.class);
                intet.putExtra("search",thewordfromsearch);
                startActivity(intet);
                break;
            case R.id.tag3:
                thewordfromsearch="blood";
                intet=new Intent(MainActivity.this,ShowDream.class);
                intet.putExtra("search",thewordfromsearch);
                startActivity(intet);
                break;
            case R.id.tag4:
                thewordfromsearch="water";
                intet=new Intent(MainActivity.this,ShowDream.class);
                intet.putExtra("search",thewordfromsearch);
                startActivity(intet);
                break;
            case R.id.tag5:
                thewordfromsearch="food";
                intet=new Intent(MainActivity.this,ShowDream.class);
                intet.putExtra("search",thewordfromsearch);
                startActivity(intet);
                break;
            case R.id.tag6:
                thewordfromsearch="love";
                intet=new Intent(MainActivity.this,ShowDream.class);
                intet.putExtra("search",thewordfromsearch);
                startActivity(intet);
                break;




        }

    }
}
